
































#ifndef cifvN
#define cifvN
#include <TypeIVRMLDefinitions.h>
namespace BkjIW{








class rO2fB{public:





rO2fB(void);





~rO2fB(void);
























void TL5H9(const double&FIIgF,const double&ievOa,const double&umT1c,const double
&r7FrR,const double&WE0dX);
























void qkMx3(double*FIIgF,double*ievOa,double*umT1c,double*r7FrR,double*WE0dX)
const;


























void wyYal(unsigned int*Z1XcN,double*PylFK,double*jHan_,double*P8xiE)const;














double cPb5F(const double&YfEuF)const;





unsigned int d6snH;






double FTf8f;






double PG51e;






double yTfgT;






double _Bp69;






double Mlr3t;};
















struct jKICA{





int Ti1i1;










double So6Nc[bfmk1];











rO2fB ZMssN[bfmk1];











rO2fB YWp8I[bfmk1];











rO2fB sabLl[bfmk1];};}
#endif

