


































#ifndef VR7hc
#define VR7hc
#include <TypeIVRMLStep1Decisions.h> 
#include <TypeIVRMLStep2Decisions.h> 
#include <TypeIVRMLMath.h>
#include <TypeIVRMLDefinitions.h>
namespace BkjIW{










enum cBgxk{
wnb2g=(0x15c4+1921-0x1d44),
YB481=(0x2484+195-0x2545),
YmqPd=(0x1e83+1097-0x22c9),
UoH_Q=(0x1fa2+1745-0x266f)};













inline bool Pjr5p(const double&OFgA6){return(!NrRvN(OFgA6));}
















inline bool et6lt(const double&OFgA6,const double&TmpZN){return(!HNEb0(OFgA6,
TmpZN));}






















inline bool JPylN(const double&OFgA6,const double&qI8hj,const double&_DBry,const
 double&q5nqO){return(Rj2f6(OFgA6,qI8hj,_DBry,kiQzO,q5nqO));}









inline bool NPlTN(const double&OFgA6,const double&TmpZN,const double&qI8hj,const
 double&_DBry,const double&q5nqO){return(DqcIa(OFgA6,TmpZN,qI8hj,_DBry,q5nqO));}









inline bool KfGG_(const double&OFgA6,const double&TmpZN,const double&qI8hj,const
 double&_DBry,const double&q5nqO){return(kP90X(OFgA6,TmpZN,qI8hj,_DBry,q5nqO));}









inline bool Lerqv(const double&OFgA6,const double&qI8hj,const double&_DBry,const
 double&q5nqO,const double&pJfW2,const double&SynchronizationTime){return(dnOyS(
OFgA6,qI8hj,_DBry,q5nqO,pJfW2,SynchronizationTime));}




























inline double e_az6(const double&OFgA6,const double&TmpZN,const double&qI8hj,
const double&_DBry,const double&q5nqO){return((lJXU0(OFgA6)+2.0*(TmpZN*(TmpZN-
OFgA6)+q5nqO*(_DBry-qI8hj)))/(2.0*TmpZN*q5nqO));}

























inline double vwNO_(const double&OFgA6,const double&qI8hj,const double&_DBry,
const double&q5nqO){return((mdAxL(2.0*(lJXU0(q5nqO)*(lJXU0(OFgA6)+2.0*q5nqO*(
_DBry-qI8hj))))-OFgA6*q5nqO)/lJXU0(q5nqO));}




























inline double Qfb2o(const double&OFgA6,const double&TmpZN,const double&qI8hj,
const double&_DBry,const double&q5nqO){return((lJXU0(OFgA6)+2.0*(TmpZN*(OFgA6+
TmpZN)+q5nqO*(qI8hj-_DBry)))/(2.0*TmpZN*q5nqO));}

























inline double upVNM(const double&OFgA6,const double&qI8hj,const double&_DBry,
const double&q5nqO){return((OFgA6+mdAxL(2.0*(lJXU0(OFgA6)+2.0*q5nqO*(qI8hj-_DBry
))))/q5nqO);}}
#endif

