





































#ifndef Skmed
#define Skmed
#include <TypeIVRMLMath.h>
namespace BkjIW{








enum RnVrR{
h0Qso,
sJjGC,
bZ8LB};
























































RnVrR dTpcB(const double&Dk1wk,const double&qI8hj,const double&OFgA6,const 
double&q5nqO,const double&TmpZN,const double&qXUgQ,const double&qPN_6,const 
double&_DBry,const int&DRRsv);}
#endif

