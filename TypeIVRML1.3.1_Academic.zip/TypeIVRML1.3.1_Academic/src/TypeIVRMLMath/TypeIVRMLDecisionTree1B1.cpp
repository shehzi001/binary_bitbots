
































#include <TypeIVRMLDecisionTree1B1.h>
#include <TypeIVRMLStep1Decisions.h>
#include <TypeIVRMLStep1IntermediateChangingProfiles.h>
#include <TypeIVRMLStep1IntermediateTimeProfiles.h>
#include <TypeIVRMLMath.h>
#include <RMLPositionFlags.h>
#ifdef oqv63








unsigned long long h3ZSF=(0x1dc+6140-0x19d8);
#endif


BkjIW::RnVrR BkjIW::dTpcB(const double&Dk1wk,const double&qI8hj,const double&
OFgA6,const double&q5nqO,const double&TmpZN,const double&qXUgQ,const double&
qPN_6,const double&_DBry,const int&DRRsv){double cXGdF=Dk1wk,HGmnq=qI8hj,rM_v0=
OFgA6,uRwD_=qPN_6,l4nzo=_DBry;
if(phoRj(rM_v0)){goto ew_we;}
else{
FstLa(&cXGdF,&HGmnq,&rM_v0,&uRwD_,&l4nzo);goto ew_we;}ew_we:
if(M4RBQ(rM_v0,TmpZN)){goto tSgnw;}
else{
FA6tY(&cXGdF,&HGmnq,&rM_v0,TmpZN,q5nqO);goto tSgnw;}tSgnw:
if(D8EcB(rM_v0,HGmnq,qXUgQ,q5nqO)){goto gjLQd;}
else{
okX3X(&cXGdF,&HGmnq,&rM_v0,q5nqO);
FstLa(&cXGdF,&HGmnq,&rM_v0,&uRwD_,&l4nzo);goto n9N1F;}gjLQd:
if(gupmx(HGmnq,qXUgQ)){goto ni1W7;}
else{goto n9N1F;}n9N1F:
if(DRRsv==RMLPositionFlags::GET_INTO_BOUNDARIES_FAST){
if(WNZTT(rM_v0,TmpZN,HGmnq,qXUgQ,q5nqO)){goto AIrbJ;}
else{goto CS5I_;}}else
{
if(DNlaZ(rM_v0,TmpZN,HGmnq,-qXUgQ,q5nqO)){PEwQA(&cXGdF,&HGmnq,&rM_v0,qXUgQ,TmpZN
,q5nqO);}
else{Ukjk4(&cXGdF,&HGmnq,&rM_v0,qXUgQ,q5nqO);}goto ni1W7;}AIrbJ:
if(xx6M6(rM_v0,HGmnq,qXUgQ,q5nqO)){
WJZ4n(&cXGdF,&HGmnq,&rM_v0,qXUgQ,q5nqO);goto ni1W7;}
else{
zhkRv(&cXGdF,&HGmnq,&rM_v0,qXUgQ,q5nqO);goto ni1W7;}CS5I_:
if(gMc6C(rM_v0,TmpZN,HGmnq,qXUgQ,q5nqO)){goto ud2Z0;}
else{
XcUUH(&cXGdF,&HGmnq,&rM_v0,qXUgQ,TmpZN,q5nqO);goto ni1W7;}ud2Z0:
if(r6XDq(rM_v0,TmpZN,HGmnq,qXUgQ,q5nqO)){
zhkRv(&cXGdF,&HGmnq,&rM_v0,qXUgQ,q5nqO);goto ni1W7;}
else{
fnMCM(&cXGdF,&HGmnq,&rM_v0,qXUgQ,TmpZN,q5nqO);goto ni1W7;}ni1W7:
if(osP3c(rM_v0,HGmnq,l4nzo,q5nqO)){goto zKgDT;}else{return(sJjGC);}zKgDT:
if(LOF0s(rM_v0,HGmnq,q5nqO)){

FstLa(&cXGdF,&HGmnq,&rM_v0,&uRwD_,&l4nzo);}
if(Fia93(rM_v0)){goto aeFuE;}else{goto sIJuX;}aeFuE:
if(YH02p(rM_v0,HGmnq,l4nzo,qXUgQ,q5nqO)){goto pM93R;}else{
okX3X(&cXGdF,&HGmnq,&rM_v0,q5nqO);goto QRA_H;}pM93R:
if(nfSyO(rM_v0,TmpZN,HGmnq,l4nzo,q5nqO)){goto VBDxc;}else{goto J3HbA;}VBDxc:
if(LQdf4(rM_v0,TmpZN,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){return(h0Qso);}else{return(
bZ8LB);}J3HbA:
if(JqI3z(rM_v0,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){return(h0Qso);}else{return(bZ8LB)
;}QRA_H:
if(vJfOq(rM_v0,TmpZN,HGmnq,l4nzo,q5nqO)){goto i51Cf;}else{goto ACvhl;}i51Cf:
if(azeLN(rM_v0,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){return(bZ8LB);}else{return(h0Qso)
;}ACvhl:
if(rvxI4(rM_v0,TmpZN,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){return(bZ8LB);}else{return(
h0Qso);}sIJuX:
if(xZ4vy(rM_v0,HGmnq,l4nzo,q5nqO)){goto QRA_H;}else{
KLpXt(&cXGdF,&HGmnq,&rM_v0,q5nqO);goto pM93R;}}
