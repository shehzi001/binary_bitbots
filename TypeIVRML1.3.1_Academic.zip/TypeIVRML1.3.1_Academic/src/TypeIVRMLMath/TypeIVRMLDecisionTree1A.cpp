
































#include <TypeIVRMLDecisionTree1A.h>
#include <TypeIVRMLStep1Decisions.h>
#include <TypeIVRMLMath.h>
#include <TypeIVRMLStep1IntermediateTimeProfiles.h>
#include <TypeIVRMLStep1Profiles.h>
#include <RMLPositionFlags.h>


bool BkjIW::RldDr(const double&Dk1wk,const double&qI8hj,const double&OFgA6,const
 double&q5nqO,const double&TmpZN,const double&qXUgQ,const double&qPN_6,const 
double&_DBry,const int&DRRsv,d49nB*OF0kB,double*U0PJC,double*RptGs){bool DohAl=
false;double GcdhE=0.0,cXGdF=Dk1wk,HGmnq=qI8hj,rM_v0=OFgA6,uRwD_=qPN_6,l4nzo=
_DBry;X0n_9(&GcdhE,&cXGdF,&HGmnq,&rM_v0,q5nqO,TmpZN,qXUgQ,DRRsv,&uRwD_,&l4nzo);
if(Rj2f6(rM_v0,HGmnq,l4nzo,qXUgQ,q5nqO)){goto UigAu;}else{goto X08IH;}UigAu:
if(DqcIa(rM_v0,TmpZN,HGmnq,l4nzo,q5nqO)){goto CjPcW;}else{goto XPoxH;}CjPcW:
if(UhFqM(rM_v0,TmpZN,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){goto jEpPZ;}else{goto r9QOb
;}jEpPZ:
if(MfT0m(rM_v0,TmpZN,HGmnq,qXUgQ,l4nzo,q5nqO)){goto b_Rz1;}else{goto rhRqc;}
b_Rz1:
if(zcCeA(rM_v0,TmpZN,HGmnq,qXUgQ,l4nzo,cXGdF,uRwD_,q5nqO)){
DyHQ9(&GcdhE,&cXGdF,&HGmnq,&rM_v0,qXUgQ,TmpZN,q5nqO);
r8vS1(&GcdhE,cXGdF,uRwD_,HGmnq,l4nzo,rM_v0,q5nqO,&DohAl);*OF0kB=Uawc_;goto Pnkfd
;}else{
eI_XK(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=BGSZ3;goto Pnkfd;}rhRqc:
if(OW5gg(rM_v0,TmpZN,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){goto QyAWc;}else{
eI_XK(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=BGSZ3;goto Pnkfd;}QyAWc:
if(Jt7Gp(rM_v0,TmpZN,HGmnq,qXUgQ,l4nzo,cXGdF,uRwD_,q5nqO)){
DyHQ9(&GcdhE,&cXGdF,&HGmnq,&rM_v0,qXUgQ,TmpZN,q5nqO);
FW1Ej(&GcdhE,cXGdF,uRwD_,HGmnq,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl);*OF0kB=Sxc5U;goto
 Pnkfd;}
else{
U5xly(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=cDXnH;goto Pnkfd;}r9QOb:
if(nq0A5(rM_v0,TmpZN,HGmnq,l4nzo,q5nqO)){goto oqfSy;}else{goto D4Eo5;}oqfSy:
if(vXbkP(rM_v0,TmpZN,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){
CfX0a(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=jgijf;goto Pnkfd;}else{
MLSwm(&GcdhE,&cXGdF,&HGmnq,&rM_v0,q5nqO);if(HGmnq>qXUgQ){HGmnq=qXUgQ;
}goto L3Ehr;}L3Ehr:
if(EUe9e(rM_v0,TmpZN,HGmnq,qXUgQ,q5nqO)){goto rIudu;}else{goto ZQzV_;}rIudu:
if(fRGr5(rM_v0,TmpZN,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){goto PDO19;}else{
FbhaO(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=DnaXB;goto Pnkfd;}PDO19:
if(YP_Hn(rM_v0,TmpZN,HGmnq,qXUgQ,l4nzo,cXGdF,uRwD_,q5nqO)){
_2D46(&GcdhE,&cXGdF,&HGmnq,&rM_v0,qXUgQ,TmpZN,q5nqO);
cxDC2(&GcdhE,cXGdF,uRwD_,HGmnq,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl);*OF0kB=HyDYY;goto
 Pnkfd;}else{
ZpW7I(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=rT8JN;goto Pnkfd;}ZQzV_:
if(QNJM_(rM_v0,TmpZN,HGmnq,qXUgQ,l4nzo,cXGdF,uRwD_,q5nqO)){
yrM2p(&GcdhE,&cXGdF,&HGmnq,&rM_v0,qXUgQ,q5nqO);
cxDC2(&GcdhE,cXGdF,uRwD_,HGmnq,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl);*OF0kB=UgzL4;goto
 Pnkfd;}else{
FbhaO(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=DnaXB;goto Pnkfd;}D4Eo5:
if(M5Wiu(rM_v0,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){goto uVgc_;}else{
MLSwm(&GcdhE,&cXGdF,&HGmnq,&rM_v0,q5nqO);if(HGmnq>qXUgQ){HGmnq=qXUgQ;
}goto miVhq;}uVgc_:
if(B4WzH(rM_v0,TmpZN,HGmnq,qXUgQ,l4nzo,cXGdF,uRwD_,q5nqO)){
CfX0a(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);if(
DohAl){
RVbZT(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);}*
OF0kB=jgijf;goto Pnkfd;}else{
RVbZT(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);if(
DohAl){
CfX0a(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);}*
OF0kB=J1ner;goto Pnkfd;}miVhq:
if(uFpyM(rM_v0,TmpZN,HGmnq,qXUgQ,q5nqO)){goto h6v9c;}else{goto m4Juz;}h6v9c:
if(qudKY(rM_v0,TmpZN,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){goto rIudu;}else{
Q6IRt(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=OifK3;goto Pnkfd;}m4Juz:
if(E_xXQ(rM_v0,TmpZN,HGmnq,qXUgQ,l4nzo,q5nqO)){goto d65tt;}else{goto ck2_R;}
d65tt:
if(Z6FPI(rM_v0,HGmnq,qXUgQ,l4nzo,cXGdF,uRwD_,q5nqO)){
yrM2p(&GcdhE,&cXGdF,&HGmnq,&rM_v0,qXUgQ,q5nqO);
HoPSQ(&GcdhE,cXGdF,uRwD_,HGmnq,l4nzo,rM_v0,q5nqO,&DohAl);*OF0kB=eIutJ;goto Pnkfd
;}else{
Q6IRt(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=OifK3;goto Pnkfd;}ck2_R:
if(pLzTb(rM_v0,TmpZN,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){goto ZQzV_;}else{
Q6IRt(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=OifK3;goto Pnkfd;}XPoxH:
if(AI4hv(rM_v0,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){goto LSpAs;
}else{goto qOcPr;
}LSpAs:
if(FLSEZ(rM_v0,TmpZN,HGmnq,qXUgQ,q5nqO)){goto jrrlx;}else{goto CsNSS;}jrrlx:
if(JY88s(rM_v0,TmpZN,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){goto jEpPZ;}else{
RoLS1(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=CBvij;goto Pnkfd;}CsNSS:
if(IDc_5(rM_v0,HGmnq,qXUgQ,l4nzo,cXGdF,uRwD_,q5nqO)){
BKJcM(&GcdhE,&cXGdF,&HGmnq,&rM_v0,qXUgQ,q5nqO);
r8vS1(&GcdhE,cXGdF,uRwD_,HGmnq,l4nzo,rM_v0,q5nqO,&DohAl);*OF0kB=pVKSx;goto Pnkfd
;}else{
RoLS1(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=CBvij;goto Pnkfd;}qOcPr:
if(xhmNB(rM_v0,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){
RVbZT(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=J1ner;goto Pnkfd;}else{
MLSwm(&GcdhE,&cXGdF,&HGmnq,&rM_v0,q5nqO);if(HGmnq>qXUgQ){HGmnq=qXUgQ;
}goto miVhq;}X08IH:
if(kP90X(rM_v0,TmpZN,HGmnq,l4nzo,q5nqO)){goto ReHxo;}else{goto m70uE;}ReHxo:
if(vsWAi(rM_v0,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){goto XMuoT;}else{
MLSwm(&GcdhE,&cXGdF,&HGmnq,&rM_v0,q5nqO);if(HGmnq>qXUgQ){HGmnq=qXUgQ;
}goto XyjB1;}XMuoT:
if(pbAzH(rM_v0,TmpZN,HGmnq,l4nzo,q5nqO)){goto LSpAs;}else{goto hqwcK;}hqwcK:
if(gbgIe(rM_v0,TmpZN,HGmnq,qXUgQ,q5nqO)){goto Igroz;}else{goto Vkim1;}Igroz:
if(yBX1L(rM_v0,TmpZN,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){goto KICsn;}else{
RoLS1(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=CBvij;goto Pnkfd;}KICsn:
if(xOzA2(rM_v0,TmpZN,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){goto QyAWc;}else{
cCleZ(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=mCpRV;goto Pnkfd;}Vkim1:
if(SpAka(rM_v0,TmpZN,HGmnq,qXUgQ,l4nzo,q5nqO)){goto CsNSS;}else{goto VkVuL;}
VkVuL:
if(UBUKL(rM_v0,TmpZN,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){goto p2Kuy;}else{
RoLS1(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=CBvij;goto Pnkfd;}p2Kuy:
if(OJ8LR(rM_v0,TmpZN,HGmnq,qXUgQ,l4nzo,cXGdF,uRwD_,q5nqO)){
BKJcM(&GcdhE,&cXGdF,&HGmnq,&rM_v0,qXUgQ,q5nqO);
FW1Ej(&GcdhE,cXGdF,uRwD_,HGmnq,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl);*OF0kB=RJPE9;goto
 Pnkfd;}else{
cCleZ(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=mCpRV;goto Pnkfd;}XyjB1:
if(UxUWf(rM_v0,TmpZN,HGmnq,qXUgQ,q5nqO)){goto vi7ua;}else{goto d65tt;}vi7ua:
if(i5puw(rM_v0,TmpZN,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){goto lyyDd;}else{
Q6IRt(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=OifK3;goto Pnkfd;}lyyDd:
if(JgFHZ(rM_v0,TmpZN,HGmnq,qXUgQ,l4nzo,q5nqO)){goto A5aQb;}else{goto oNDBP;}
A5aQb:
if(ARMKT(rM_v0,TmpZN,HGmnq,qXUgQ,l4nzo,cXGdF,uRwD_,q5nqO)){
_2D46(&GcdhE,&cXGdF,&HGmnq,&rM_v0,qXUgQ,TmpZN,q5nqO);
HoPSQ(&GcdhE,cXGdF,uRwD_,HGmnq,l4nzo,rM_v0,q5nqO,&DohAl);*OF0kB=F9rJD;goto Pnkfd
;}else{
BsyBp(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=wzOBw;goto Pnkfd;}oNDBP:
if(wmYKP(rM_v0,TmpZN,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){goto PDO19;}else{
BsyBp(&GcdhE,cXGdF,uRwD_,HGmnq,qXUgQ,l4nzo,rM_v0,TmpZN,q5nqO,&DohAl,RptGs);*
OF0kB=wzOBw;goto Pnkfd;}m70uE:
if(f1kYo(rM_v0,TmpZN,HGmnq,l4nzo,cXGdF,uRwD_,q5nqO)){goto jOAOk;}else{
MLSwm(&GcdhE,&cXGdF,&HGmnq,&rM_v0,q5nqO);if(HGmnq>qXUgQ){HGmnq=qXUgQ;
}goto lyyDd;}jOAOk:
if(Rofo0(rM_v0,TmpZN,HGmnq,qXUgQ,q5nqO)){goto KICsn;}else{goto p2Kuy;}Pnkfd:*
U0PJC=GcdhE;return(DohAl);}

void BkjIW::X0n_9(double*HcAaS,double*Dk1wk,double*qI8hj,double*OFgA6,const 
double&q5nqO,const double&TmpZN,const double&qXUgQ,const int&DRRsv,double*qPN_6,
double*_DBry){
if(NrRvN(*OFgA6)){goto QGPPG;}
else{
LIlfP(Dk1wk,qI8hj,OFgA6,qPN_6,_DBry);goto QGPPG;}QGPPG:
if(HNEb0(*OFgA6,TmpZN)){goto rpBOH;}
else{
ZbntB(HcAaS,Dk1wk,qI8hj,OFgA6,TmpZN,q5nqO);goto rpBOH;}rpBOH:
if(N4I01(*OFgA6,*qI8hj,qXUgQ,q5nqO)){goto VX3bA;}
else{
MLSwm(HcAaS,Dk1wk,qI8hj,OFgA6,q5nqO);
LIlfP(Dk1wk,qI8hj,OFgA6,qPN_6,_DBry);goto slA18;}VX3bA:
if(LePhM(*qI8hj,qXUgQ)){goto YGpUH;}
else{goto slA18;}slA18:
if(DRRsv==RMLPositionFlags::GET_INTO_BOUNDARIES_FAST){
if(ZIX9f(*OFgA6,TmpZN,*qI8hj,qXUgQ,q5nqO)){goto dFZ9d;}
else{goto RpdrX;}}else
{
if(F1s4F(*OFgA6,TmpZN,*qI8hj,-qXUgQ,q5nqO)){x96T7(HcAaS,Dk1wk,qI8hj,OFgA6,qXUgQ,
TmpZN,q5nqO);}
else{c8VVD(HcAaS,Dk1wk,qI8hj,OFgA6,qXUgQ,q5nqO);}goto YGpUH;}dFZ9d:
if(w49_J(*OFgA6,*qI8hj,qXUgQ,q5nqO)){
NbC_i(HcAaS,Dk1wk,qI8hj,OFgA6,qXUgQ,q5nqO);goto YGpUH;}
else{
V4ati(HcAaS,Dk1wk,qI8hj,OFgA6,qXUgQ,q5nqO);goto YGpUH;}RpdrX:
if(NpVpV(*OFgA6,TmpZN,*qI8hj,qXUgQ,q5nqO)){goto ah38q;}
else{
YPfXT(HcAaS,Dk1wk,qI8hj,OFgA6,qXUgQ,TmpZN,q5nqO);goto YGpUH;}ah38q:
if(aBNZo(*OFgA6,TmpZN,*qI8hj,qXUgQ,q5nqO)){
V4ati(HcAaS,Dk1wk,qI8hj,OFgA6,qXUgQ,q5nqO);goto YGpUH;}
else{
TVxU3(HcAaS,Dk1wk,qI8hj,OFgA6,qXUgQ,TmpZN,q5nqO);goto YGpUH;}YGpUH:return;}
